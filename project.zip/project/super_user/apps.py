from django.apps import AppConfig


class SuperUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'super_user'
